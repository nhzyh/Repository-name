package com.peace.tabletview;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.graphics.Color;
import android.view.View;
import android.widget.*;
import android.text.InputType;

public class MainActivity extends Activity {
    int ink=0xFF172033, muted=0xFF64748B, blue=0xFF2563EB, bg=0xFFF5F7FB;
    String ratio="4:3", mode="适配显示";
    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    LinearLayout.LayoutParams params(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    TextView label(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);
        if(bold)t.setTypeface(null,1);return t;
    }
    Button btn(String s){
        Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));return b;
    }
    void gap(LinearLayout p,int h){View v=new View(this);p.addView(v,params(1,h));}
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        ScrollView scroll=new ScrollView(this);
        LinearLayout page=new LinearLayout(this);page.setOrientation(1);page.setPadding(dp(20),dp(22),dp(20),dp(26));page.setBackgroundColor(bg);
        scroll.addView(page);
        TextView status=label("当前选择：4:3 · 适配显示",14,blue,true);
        page.addView(label("平板视角助手",27,ink,true));
        TextView sub=label("一加 Ace 7 · 和平精英显示适配工具",14,muted,false);gap(page,4);page.addView(sub);
        gap(page,20);
        TextView note=label("默认配置：4:3 · 适配显示\n\n本工具不需要 Root，不修改游戏文件，不注入游戏。普通权限无法强制改变和平精英内部渲染视野。",15,ink,false);
        note.setPadding(dp(15),dp(15),dp(15),dp(15));note.setBackgroundColor(0xFFE6EEFC);page.addView(note);
        gap(page,22);page.addView(label("显示比例",19,ink,true));gap(page,8);
        LinearLayout ratios=new LinearLayout(this);ratios.setOrientation(0);
        for(String r:new String[]{"4:3","16:9","16:10"}){
            Button rb=new Button(this);rb.setText(r);rb.setAllCaps(false);
            rb.setTextColor(r.equals(ratio)?Color.WHITE:ink);
            rb.setBackgroundTintList(android.content.res.ColorStateList.valueOf(r.equals(ratio)?blue:0xFFE5EAF2));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,dp(48),1);rp.setMargins(dp(3),0,dp(3),0);ratios.addView(rb,rp);
            rb.setOnClickListener(v->{ratio=r; for(int i=0;i<ratios.getChildCount();i++){Button x=(Button)ratios.getChildAt(i);boolean sel=x.getText().toString().equals(ratio);x.setTextColor(sel?Color.WHITE:ink);x.setBackgroundTintList(android.content.res.ColorStateList.valueOf(sel?blue:0xFFE5EAF2));}status.setText("当前选择："+ratio+" · "+mode);});
        }
        page.addView(ratios);
        gap(page,20);page.addView(label("显示模式",19,ink,true));gap(page,5);
        RadioGroup modes=new RadioGroup(this);modes.setOrientation(1);
        String[] opts={"适配显示","保持比例","拉伸显示"};
        for(String s:opts){RadioButton rb=new RadioButton(this);rb.setText(s);rb.setTextSize(15);rb.setTextColor(ink);rb.setId(View.generateViewId());rb.setChecked(s.equals(mode));modes.addView(rb);}
        modes.setOnCheckedChangeListener((g,id)->{RadioButton r=findViewById(id);if(r!=null){mode=r.getText().toString();status.setText("当前选择："+ratio+" · "+mode);}});
        page.addView(modes);
        gap(page,12);page.addView(status);
        gap(page,18);page.addView(label("比例计算器",19,ink,true));gap(page,5);
        EditText width=new EditText(this);width.setSingleLine(true);width.setInputType(InputType.TYPE_CLASS_NUMBER);width.setHint("输入宽度像素，例如 1080");page.addView(width,params(-1,-2));
        TextView result=label("计算对应高度，方便理解画面比例。",14,muted,false);gap(page,5);page.addView(result);
        Button calc=btn("计算当前比例高度");page.addView(calc,params(-1,48));
        calc.setOnClickListener(v->{try{int w=Integer.parseInt(width.getText().toString().trim());if(w<=0)throw new Exception();String[] a=ratio.split(":");int h=Math.round(w*Integer.parseInt(a[1])/(float)Integer.parseInt(a[0]));result.setText(ratio+" 对应尺寸："+w+" × "+h+" 像素");}catch(Exception e){result.setText("请输入有效的正整数宽度。");}});
        gap(page,20);page.addView(label("系统显示设置",19,ink,true));gap(page,5);
        page.addView(label("打开系统设置后，检查是否提供应用全屏、应用显示比例或屏幕缩放选项。不同系统版本可能不同。",14,muted,false));
        Button display=btn("打开手机显示设置");gap(page,8);page.addView(display,params(-1,48));
        display.setOnClickListener(v->open(Settings.ACTION_DISPLAY_SETTINGS));
        Button apps=btn("打开应用管理设置");gap(page,6);page.addView(apps,params(-1,48));
        apps.setOnClickListener(v->open(Settings.ACTION_APPLICATION_SETTINGS));
        gap(page,18);
        TextView warning=label("真实功能说明\n• 可选择 4:3、16:9、16:10，并计算对应尺寸。\n• 可打开手机系统显示设置，供你手动检查厂商提供的选项。\n• 不会自动修改系统分辨率、DPI 或游戏数据。\n• 选择比例只改变本工具中的配置，不会直接改变和平精英画面或视野。",13,muted,false);
        warning.setPadding(dp(14),dp(14),dp(14),dp(14));warning.setBackgroundColor(0xFFE9EDF3);page.addView(warning);
        setContentView(scroll);
    }
    void open(String action){try{startActivity(new Intent(action));}catch(Exception e){startActivity(new Intent(Settings.ACTION_SETTINGS));}}
}
